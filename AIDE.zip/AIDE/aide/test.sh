
a=5

if [ $a -eq 0 -o $a -eq 5 ]

then

echo "I M Hero"

else
echo "I M Super"
fi
