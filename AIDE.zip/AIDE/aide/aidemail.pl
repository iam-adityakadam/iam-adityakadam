#!/usr/bin/perl


$data_file="/home/aide/finalcheck.log";
open(DAT, $data_file) || die("Could not open the log file!");
@data=<DAT>;

use Net::SMTP;


#$SMTP_SERVER = '10.6.4.250';
#$SMTP_SERVER = '10.6.4.4';
#$SMTP_SERVER = '10.6.102.29';
#$SMTP_SERVER = '10.6.4.62';
$SMTP_SERVER = 'icftp.kotakseconline.com';
$from = "aide\@kslibomnir";
#@EMAIL_TO =('vijay.chavan@kotak.com');
#@EMAIL_TO =('s.shankar@kotak.com','nilesh.vaity@kotak.com');
@EMAIL_TO =('kslinux.team@kotak.com');
#@EMAIL_TO =('jalpan.trivedi@kotak.com');
#@EMAIL_TO =('sachin.patil@kotak.com');
#@EMAIL_TO =('s.shankar@kotak.com','nilesh.vaity@kotak.com','sachin.patil@kotak.com','vijay.chavan@kotak.com');
$subject = "AIDE Report";

$smtp = Net::SMTP->new($SMTP_SERVER);
die "Failed to connect to $SMTP_SERVER" unless $smtp;

@email_addresses = (@email_addresses, @EMAIL_TO);
foreach my $to_addr (@email_addresses) 
	{
	$smtp->mail($from);
	$smtp->to("$to_addr\n");
	$smtp->data();
	$smtp->datasend("To: $to_addr\n");
	$smtp->datasend("From: $from\n");
	$smtp->datasend("Subject: $subject\n");
	$smtp->datasend("X-Mailer: Perl\n");
	$smtp->datasend("\n");
	$smtp->datasend("@data\n");
	$smtp->dataend();
	}
	
$smtp->quit();


