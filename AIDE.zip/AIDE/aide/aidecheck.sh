#!/bin/bash
> /home/aide/aidecheck.log
> /home/aide/aidediff.log
> /home/aide/finalcheck.log

echo "Start time is: `date`" >> /home/aide/aidecheck.log
hs=`hostname`
echo "Hostname of Server: $hs" >> /home/aide/aidecheck.log
ip=`ifconfig | grep -w inet | awk '{print $2}' | head -n 1`
echo "IP Adress of Serevr: $ip" >> /home/aide/aidecheck.log
fqdn=`nslookup $ip | grep -v Server | grep -v Address |  awk '{print $4}'`
echo "FQDN of Server: $fqdn" >> /home/aide/aidecheck.log  

if [ -f /var/lib/aide/aide.db.new.gz ]  || [ -f /var/lib/aide/aide.db.gz  ]

then
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> /home/aide/aidecheck.log 2>&1
echo "Old Database present for check" >> /home/aide/aidecheck.log 2>&1
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> /home/aide/aidecheck.log 2>&1

if [ -s /var/lib/aide/aide.db.new.gz ]
then

mv /var/lib/aide/aide.db.new.gz /var/lib/aide/aide.db.gz

fi

else

echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> /home/aide/aidecheck.log 2>&1
echo "Initializing new database for check" >> /home/aide/aidecheck.log 2>&1
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> /home/aide/aidecheck.log 2>&1

/usr/bin/ionice -c3 /usr/sbin/aide --init

if [ -s /var/lib/aide/aide.db.new.gz ]
then

echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> /home/aide/aidecheck.log 2>&1
echo "Initialization of new database completed" >> /home/aide/aidecheck.log 2>&1
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> /home/aide/aidecheck.log 2>&1

mv /var/lib/aide/aide.db.new.gz /var/lib/aide/aide.db.gz

fi
fi

/usr/bin/ionice -c3 /usr/sbin/aide --check | grep -v "lgetfilecon_raw"  >> /home/aide/aidediff.log 2>&1

/usr/bin/ionice -c3 /usr/sbin/aide --update

mv /var/lib/aide/aide.db.gz /var/lib/aide/aide.db.gz_`date +%d"_"%b"_"%Y`

if [ $? -eq 0 ]
then

mv /var/lib/aide/aide.db.new.gz /var/lib/aide/aide.db.gz

if [ $? -eq 0 ]

then

echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> /home/aide/aidecheck.log 2>&1
echo "New AIDE database created for next check" >> /home/aide/aidecheck.log 2>&1
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> /home/aide/aidecheck.log 2>&1

else
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> /home/aide/aidecheck.log 2>&1
echo "Unable to create new database for next check" >> /home/aide/aidecheck.log 2>&1
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> /home/aide/aidecheck.log 2>&1
fi

else
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> /home/aide/aidecheck.log 2>&1
echo "Unable to move old database" >> /home/aide/aidecheck.log 2>&1
echo "+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++" >> /home/aide/aidecheck.log 2>&1
fi
echo "End time is: `date`" >> /home/aide/aidecheck.log
cat /home/aide/aidecheck.log /home/aide/aidediff.log > /home/aide/finalcheck.log
/home/aide/aidemail.pl
